import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';

@IonicPage()
@Component({
  selector: 'page-notificacion',
  templateUrl: 'notificacion.html',
})
export class NotificacionPage {

  public cursadas: any = [];
  public mesas: any = [];

  /* DEFINE LA CONEXION CON EL SERVIDOR */
  public baseURI: string = "http://localhost/Tempus/api/";

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public http: Http,
    public toastController: ToastController) {
  }

  ionViewDidLoad() {
    this.consultarCursadas();
    this.consultarMesas();
  }

  consultarCursadas() {
    let
      body: string = "marca=true",
      type: string = "application/x-www-form-urlencoded; charset=UTF-8",
      headers: any = new Headers({ 'Content-Type': type }),
      options: any = new RequestOptions({ headers: headers }),
      url: any = this.baseURI + "novedad_cursada.php";

    this.http.post(url, body, options)
      .subscribe(data => {
        if (data.status === 200) {
          let response = data.json();
          if (response.estado == 'OK') {
            this.cursadas = response.datos;
          } else {
            this.enviarNotificacion(response.datos);
          }
        } else {
          this.enviarNotificacion("No se pudo procesar la petición");
        }
      });
  }

  consultarMesas() {
    let
      body: string = "marca=true",
      type: string = "application/x-www-form-urlencoded; charset=UTF-8",
      headers: any = new Headers({ 'Content-Type': type }),
      options: any = new RequestOptions({ headers: headers }),
      url: any = this.baseURI + "novedad_mesa.php";

    this.http.post(url, body, options)
      .subscribe(data => {
        if (data.status === 200) {
          let response = data.json();
          if (response.estado == 'OK') {
            this.mesas = response.datos;
          } else {
            this.enviarNotificacion(response.datos);
          }
        } else {
          this.enviarNotificacion("No se pudo procesar la petición");
        }
      });
  }

  /* ENVIA UNA NOTIFICACION QUE RECIBE POR PARAMETRO. */

  enviarNotificacion(mensaje): void {
    let notification = this.toastController.create({
      message: mensaje,
      duration: 3000
    });
    notification.present();
  }

}
