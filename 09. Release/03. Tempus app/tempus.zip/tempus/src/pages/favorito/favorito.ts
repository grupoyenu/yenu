import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-favorito',
  templateUrl: 'favorito.html',
})
export class FavoritoPage {

  public cursadas: any = [];
  public mesas: any = [];

  private storage: Storage;
  private KEY_CURSADAS = 'CURSADAS';
  private KEY_MESAS = 'MESAS';

  /* DEFINE LA CONEXION CON EL SERVIDOR */
  public baseURI: string = "http://localhost/Tempus/api/";

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public http: Http,
    public formBuilder: FormBuilder,
    public toastController: ToastController,
    private storages: Storage) {
    this.storage = storages;
  }

  /* Consulta los horarios de cursada a partir de los id en Storage */

  consultarCursadas() {
    this.storage.get(this.KEY_CURSADAS).then((items: any[]) => {
      if (items) {
        var planes = '(';
        for (let i = 0; i < items.length; i++) {
          planes = planes + items[i] + ',';
        }
        planes = planes.substring(0, planes.length - 1) + ')';
        let body: string = "idPlan=" + planes,
          type: string = "application/x-www-form-urlencoded; charset=UTF-8",
          headers: any = new Headers({ 'Content-Type': type }),
          options: any = new RequestOptions({ headers: headers }),
          url: any = this.baseURI + "get_cursada.php";
        this.http.post(url, body, options).subscribe(data => {
          if (data.status === 200) {
            let response = data.json();
            if (response.estado === 'OK') {
              this.cursadas = response.datos;
            } else {
              this.enviarNotificacion(response.datos);
            }
          } else {
            this.enviarNotificacion("No se pudo procesar la petición");
          }
        });
      }
    });
  }

  /* Consulta la mesas de examen a partir de los id en Storage */

  consultarMesas() {
    this.storage.get(this.KEY_MESAS).then((items: any[]) => {
      if (items) {
        var planes = '(';
        for (let i = 0; i < items.length; i++) {
          planes = planes + items[i] + ',';
        }
        planes = planes.substring(0, planes.length - 1) + ')';
        let body: string = "idPlan=" + planes,
          type: string = "application/x-www-form-urlencoded; charset=UTF-8",
          headers: any = new Headers({ 'Content-Type': type }),
          options: any = new RequestOptions({ headers: headers }),
          url: any = this.baseURI + "get_mesa.php";
        this.http.post(url, body, options).subscribe(data => {
          if (data.status === 200) {
            let response = data.json();
            if (response.estado === 'OK') {
              this.mesas = response.datos;
            } else {
              this.enviarNotificacion(response.datos);
            }
          } else {
            this.enviarNotificacion("No se pudo procesar la petición");
          }
        });
      }
    });
  }

  /* Envia una notificacion a partir del mensaje que recibe. */
  enviarNotificacion(mensaje): void {
    let notification = this.toastController.create({
      message: mensaje,
      duration: 3000
    });
    notification.present();
  }

}
