import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@IonicPage()
@Component({
	selector: 'page-cursada',
	templateUrl: 'cursada.html',
})
export class CursadaPage {

	public form: FormGroup;
	public cursadaCarrera: any;
	public cursadaAsignatura: any;
	public cursadaAnio: any;
	public asignaturas: any = [];
	public carreras: any = [];
	public cursadas: any = [];

	// IDENTIFICADORES PARA LA CARRERA Y ASIGNATURA
	public idasignatura: any = null;
	public idcarrera: any = null;

	// URL DEL LOCALHOST 
	public baseURI: string = "http://localhost/Tempus/api/";

	constructor(public navController: NavController,
		public http: Http,
		public navParams: NavParams,
		public formBuilder: FormBuilder,
		public toastController: ToastController) {

		console.log('Cursada.ts -> constructor');
		/* REALIZA LA CREACION DEL FORMULARIO */

		this.form = formBuilder.group({
			"carrera": ["", Validators.required],
			"asignatura": [""],
			"anio": [""]
		});

	}

	ionViewDidLoad() {
		console.log('ionViewDidLoad CursadaPage');
		this.cargarCarreras();
	}

	cargarAsignaturas() {
		console.log('cargarAsignaturas()');
		let carrera: string = this.form.controls["carrera"].value;
		let body: string = "idCarrera=" + carrera,
			type: string = "application/x-www-form-urlencoded; charset=UTF-8",
			headers: any = new Headers({ 'Content-Type': type }),
			options: any = new RequestOptions({ headers: headers }),
			url: any = this.baseURI + "listar_asignaturas_cursada.php";
		this.http.post(url, body, options).subscribe(data => {
			console.log(data.json());
			if (data.status === 200) {
				let response = data.json();
				this.asignaturas = response.datos;
			} else {
				this.enviarNotificacion('No se pudo procesar la carga de asignaturas');
			}
		});
	}

	cargarCarreras() {
		console.log('Cursada.ts -> CargarCarreras');
		let body: string = "",
			type: string = "application/x-www-form-urlencoded; charset=UTF-8",
			headers: any = new Headers({ 'Content-Type': type }),
			options: any = new RequestOptions({ headers: headers }),
			url: any = this.baseURI + "listar_carreras_cursada.php";
		this.http.post(url, body, options).subscribe(data => {
			console.log('Data:', data);
			if (data.status === 200) {
				console.log('Cursada.ts -> CargarCarreras -> status 200');
				let response = data.json();
				this.carreras = response.datos;
			} else {
				this.enviarNotificacion('No se pudo procesar la carga de carreras');
			}
		});
	}

	consultarCursadas() {
		console.log(' Entro al consultarCursadas ');

		if (this.form.valid) {
			if ((this.form.controls["asignatura"].value == '') && (this.form.controls["anio"].value == null)) {
				this.enviarNotificacion("Debe indicar nombre de asignatura o año");
			} else {
				let carrera: string = this.form.controls["carrera"].value,
					asignatura: string = this.form.controls["asignatura"].value,
					anio: any = this.form.controls["anio"].value,
					body: string = "&idCarrera=" + carrera + "&idAsignatura=" + asignatura + "&anio=" + anio,
					type: string = "application/x-www-form-urlencoded; charset=UTF-8",
					headers: any = new Headers({ 'Content-Type': type }),
					options: any = new RequestOptions({ headers: headers }),
					url: any = this.baseURI + "listar_cursada.php";

				this.http.post(url, body, options)
					.subscribe(data => {
						console.log(data.json());
						if (data.status === 200) {
							console.log(data.json());
							let response = data.json();
							if (response.estado == 'OK') {
								this.cursadas = response.datos;
							} else {
								this.enviarNotificacion(response.datos);
							}
						} else {
							this.enviarNotificacion("No se pudo procesar la petición");
						}
					});
			}
		} else {
			this.enviarNotificacion("Por favor, complete el formulario");
		}
	}

	/*
	 * ENVIA UNA NOTIFICACION QUE RECIBE POR PARAMETRO. 
	 */
	enviarNotificacion(mensaje): void {
		let notification = this.toastController.create({
			message: mensaje,
			duration: 3000
		});
		notification.present();
	}

}
