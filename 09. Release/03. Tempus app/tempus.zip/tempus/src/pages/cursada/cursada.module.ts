import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CursadaPage } from './cursada';

@NgModule({
  declarations: [
    CursadaPage,
  ],
  imports: [
    IonicPageModule.forChild(CursadaPage),
  ],
})
export class CursadaPageModule {}
