import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@IonicPage()
@Component({
	selector: 'page-mesa',
	templateUrl: 'mesa.html',
})
export class MesaPage {

	/* DEFINE EL FORMULARIO Y LOS CAMPOS */
	public form: FormGroup;
	public mesaCarrera: any;
	public mesaAsignatura: any;
	public mesaDocente: any;
	/* DEFINE LOS ARREGLOS NECESARIOS PARA CARGAR EL FORMULARIO (DESDE LA BD) */
	public carreras: any = [];
	public mesas: any = [];
	public asignaturas: any = [];
	/* DEFINE LA CONEXION CON EL SERVIDOR */
	public baseURI: string = "http://localhost/Tempus/api/";

	constructor(public navCtrl: NavController,
		public navParams: NavParams,
		public http: Http,
		public formBuilder: FormBuilder,
		public toastController: ToastController) {
		/* REALIZA LA CREACION CON LAS CARACTERISTICAS A VALIDAR */
		this.form = formBuilder.group({
			"carrera": ["", Validators.required],
			"asignatura": [""],
			"docente": [""]
		});
	}

	ionViewDidLoad() {
		console.log('ionViewDidLoad MesaPage');
		this.cargarCarreras();
	}

	cargarCarreras() {
		console.log('cargarCarreras()');
		let body: string = "",
			type: string = "application/x-www-form-urlencoded; charset=UTF-8",
			headers: any = new Headers({ 'Content-Type': type }),
			options: any = new RequestOptions({ headers: headers }),
			url: any = this.baseURI + "listar_carreras_mesa.php";
		this.http.post(url, body, options).subscribe(data => {
			console.log(data.json());
			if (data.status === 200) {
				let response = data.json();
				this.carreras = response.datos;
			} else {
				console.log("No se pudo procesar la petición");
			}
		});
	}

	/* CARGA EL SELECTOR DE ASIGNATURAS CUANDO SE CAMBIA LA CARRERA */

	cargarAsignaturas() {
		console.log('cargarAsignaturas()');
		let carrera: string = this.form.controls["carrera"].value;
		let body: string = "idCarrera=" + carrera,
			type: string = "application/x-www-form-urlencoded; charset=UTF-8",
			headers: any = new Headers({ 'Content-Type': type }),
			options: any = new RequestOptions({ headers: headers }),
			url: any = this.baseURI + "listar_asignaturas_mesa.php";
		this.http.post(url, body, options).subscribe(data => {
			console.log(data.json());
			if (data.status === 200) {
				let response = data.json();
				this.asignaturas = response.datos;
			} else {
				this.enviarNotificacion('No se pudo procesar la carga de asignaturas');
			}
		});
	}

	consultarMesas() {
		console.log('consultarMesas MesaPage');
		if (this.form.valid) {
			if ((this.form.controls["asignatura"].value == '') && (this.form.controls["docente"].value == null)) {
				this.enviarNotificacion("Debe indicar nombre de asignatura o nombre de docente");
			} else {
				let carrera: string = this.form.controls["carrera"].value,
					asignatura: string = this.form.controls["asignatura"].value,
					docente: string = this.form.controls["docente"].value,
					body: string = "idCarrera=" + carrera + "&idAsignatura=" + asignatura + "&docente=" + docente,
					type: string = "application/x-www-form-urlencoded; charset=UTF-8",
					headers: any = new Headers({ 'Content-Type': type }),
					options: any = new RequestOptions({ headers: headers }),
					url: any = this.baseURI + "listar_mesa.php";

				this.http.post(url, body, options)
					.subscribe(data => {
						console.log(data.json());
						if (data.status === 200) {
							let response = data.json();
							if (response.estado == 'OK') {
								this.mesas = response.datos;
							} else {
								this.enviarNotificacion(response.datos);
							}
						} else {
							this.enviarNotificacion("No se pudo procesar la petición");
						}
					});
			}
		} else {
			this.enviarNotificacion("Por favor, complete el formulario");
		}

	}

	/* ENVIA UNA NOTIFICACION QUE RECIBE POR PARAMETRO. */
	enviarNotificacion(mensaje): void {
		let notification = this.toastController.create({
			message: mensaje,
			duration: 3000
		});
		notification.present();
	}

}
