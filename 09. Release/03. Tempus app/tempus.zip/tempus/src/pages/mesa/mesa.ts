import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
	selector: 'page-mesa',
	templateUrl: 'mesa.html',
})
export class MesaPage {

	/* DEFINE EL FORMULARIO Y LOS CAMPOS */
	public form: FormGroup;
	public mesaCarrera: any;
	public mesaAsignatura: any;
	public mesaDocente: any;

	/* DEFINE LOS ARREGLOS NECESARIOS PARA CARGAR EL FORMULARIO (DESDE LA BD) */
	public carreras: any = [];
	public mesas: any = [];
	public asignaturas: any = [];

	/* DEFINE LA CONEXION CON EL SERVIDOR */
	public baseURI: string = "http://localhost/Tempus/api/";

	/* DEFINE LOS ATRIBUTOS PARA CONTROLAR FAVORITOS */
	private storage: Storage;
	private KEY = 'MESAS';


	constructor(public navCtrl: NavController,
		public navParams: NavParams,
		public http: Http,
		public formBuilder: FormBuilder,
		public toastController: ToastController,
		private storages: Storage) {
		/* REALIZA LA CREACION CON LAS CARACTERISTICAS A VALIDAR */
		this.form = formBuilder.group({
			"carrera": ["", Validators.required],
			"asignatura": [""],
			"docente": [""]
		});
		this.storage = storages;
	}

	ionViewDidLoad() {
		if (this.mesas && this.mesas.length > 0) {
			this.mesas = [];
		}
		this.cargarCarreras();
	}

	cargarCarreras() {
		let body: string = "",
			type: string = "application/x-www-form-urlencoded; charset=UTF-8",
			headers: any = new Headers({ 'Content-Type': type }),
			options: any = new RequestOptions({ headers: headers }),
			url: any = this.baseURI + "listar_carreras_mesa.php";
		this.http.post(url, body, options).subscribe(data => {
			if (data.status === 200) {
				let response = data.json();
				this.carreras = response.datos;
			} else {
				this.enviarNotificacion('No se pudo procesar la carga de carreras');
			}
		});
	}

	/* CARGA EL SELECTOR DE ASIGNATURAS CUANDO SE CAMBIA LA CARRERA */

	cargarAsignaturas() {
		let carrera: string = this.form.controls["carrera"].value;
		let body: string = "idCarrera=" + carrera,
			type: string = "application/x-www-form-urlencoded; charset=UTF-8",
			headers: any = new Headers({ 'Content-Type': type }),
			options: any = new RequestOptions({ headers: headers }),
			url: any = this.baseURI + "listar_asignaturas_mesa.php";
		this.http.post(url, body, options).subscribe(data => {
			if (data.status === 200) {
				let response = data.json();
				this.asignaturas = response.datos;
			} else {
				this.enviarNotificacion('No se pudo procesar la carga de asignaturas');
			}
		});
	}

	consultarMesas() {
		if (this.form.valid) {
			if ((this.form.controls["asignatura"].value == '') && (this.form.controls["docente"].value == null)) {
				this.enviarNotificacion("Debe indicar nombre de asignatura o nombre de docente");
			} else {
				let carrera: string = this.form.controls["carrera"].value,
					asignatura: string = this.form.controls["asignatura"].value,
					docente: string = this.form.controls["docente"].value,
					body: string = "idCarrera=" + carrera + "&idAsignatura=" + asignatura + "&docente=" + docente,
					type: string = "application/x-www-form-urlencoded; charset=UTF-8",
					headers: any = new Headers({ 'Content-Type': type }),
					options: any = new RequestOptions({ headers: headers }),
					url: any = this.baseURI + "listar_mesa.php";

				this.http.post(url, body, options)
					.subscribe(data => {
						if (data.status === 200) {
							let response = data.json();
							if (response.estado == 'OK') {
								this.mesas = response.datos;
								/* BUSCA LAS MESAS QUE ESTAN ALMACENADAS COMO FAVORITAS */
								this.storage.get(this.KEY).then((items: any[]) => {
									if (items) {
										for (let i = 0; i < this.mesas.length; i++) {
											let idPlan = this.mesas[i]['idPlan'];
											if (items.indexOf(idPlan) > 0) {
												this.mesas[i]['favorito'] = true;
											}
										}
									}
								});
							} else {
								this.enviarNotificacion(response.datos);
							}
						} else {
							this.enviarNotificacion("No se pudo procesar la petición");
						}
					});
			}
		} else {
			this.enviarNotificacion("Por favor, complete el formulario");
		}
	}

	agregarFavorito(item) {
		item.favorito = true;
		let idPlan = item.idPlan;
		let asignatura = item.nombreLargoAsignatura;
		this.storage.get(this.KEY).then((items: any[]) => {
			if (items) {
				/* Agrega el item y guarda en storage */
				let posicion = items.indexOf(idPlan);
				if (posicion === -1) {
					items.push(idPlan);
					return this.storage.set(this.KEY, items);
				}
				return this.storage.set(this.KEY, items);
			} else {
				return this.storage.set(this.KEY, [idPlan]);
			}
		});
		this.enviarNotificacion(asignatura + ' se agregó como favorito');
	}

	quitarFavorito(item) {
		item.favorito = false;
		let idPlan = item.idPlan;
		let asignatura = item.nombreLargoAsignatura;
		this.storage.get(this.KEY).then((items: any[]) => {
			if (!items || items.length === 0) {
				return null;
			}
			let nuevo: any = [];
			for (let item of items) {
				if (item !== idPlan) {
					nuevo.push(item);
				}
			}
			return this.storage.set(this.KEY, nuevo);
		});
		this.enviarNotificacion(asignatura + ' se quitó como favorito');
	}

	/* ENVIA UNA NOTIFICACION QUE RECIBE POR PARAMETRO. */

	enviarNotificacion(mensaje): void {
		let notification = this.toastController.create({
			message: mensaje,
			duration: 3000
		});
		notification.present();
	}

}
