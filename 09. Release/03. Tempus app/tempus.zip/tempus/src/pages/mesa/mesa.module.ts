import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MesaPage } from './mesa';

@NgModule({
  declarations: [
    MesaPage,
  ],
  imports: [
    IonicPageModule.forChild(MesaPage),
  ],
})
export class MesaPageModule {}
